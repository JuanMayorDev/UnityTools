Unity VFX tools for Houdini
===========================

Requirements:
=============

 * Houdini 17 Apprentice, Indie, Core or FX


Install:
========

 * Use the File > Import > Houdini Digital Asset to Import the Unity_VFX_Tools.hda file.
 * If you have a workspace set-up with your tools (eg: GameDevelopmentToolset), you can put the .hda file in the /otls directory so it's imported at startup.


Release Notes:
==============

    2018 - 11 - 02: 
    ---------------
    Initial Version
        - Volume Exporter
        - Point Cache Exporter