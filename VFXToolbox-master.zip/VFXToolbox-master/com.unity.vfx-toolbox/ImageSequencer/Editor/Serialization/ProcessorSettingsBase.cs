using UnityEngine;

namespace UnityEditor.VFXToolbox.ImageSequencer
{
    public abstract class ProcessorSettingsBase : ScriptableObject
    {
        public abstract void Default();
    }
}


